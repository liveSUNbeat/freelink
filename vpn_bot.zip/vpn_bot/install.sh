#!/bin/bash

# Проверка прав root
if [ "$EUID" -ne 0 ]; then 
  echo "Пожалуйста, запустите этот скрипт от имени root (используйте sudo)"
  exit
fi

echo "Обновление списка пакетов..."
apt update && apt upgrade -y

echo "Установка WireGuard, Python и pip..."
apt install -y wireguard python3 python3-pip python3-venv qrencode

# Включение IP forwarding (нужно для работы VPN)
echo "Настройка IP forwarding..."
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/' /etc/sysctl.conf
sysctl -p

# Создание директории для ключей WireGuard
mkdir -p /etc/wireguard
cd /etc/wireguard
umask 077

# Генерация ключей сервера, если их нет
if [ ! -f privatekey ]; then
    echo "Генерация ключей сервера..."
    wg genkey | tee privatekey | wg pubkey > publickey
fi

SERVER_PRIV_KEY=$(cat /etc/wireguard/privatekey)
SERVER_PUB_KEY=$(cat /etc/wireguard/publickey)

# Определение сетевого интерфейса (обычно eth0, но может отличаться)
# Берем первый интерфейс, который является шлюзом по умолчанию
NET_INTERFACE=$(ip route | grep default | awk '{print $5}' | head -1)

if [ -z "$NET_INTERFACE" ]; then
    NET_INTERFACE="eth0" # Fallback
fi

echo "Используемый сетевой интерфейс: $NET_INTERFACE"

# Создание конфигурации сервера, если нет
if [ ! -f wg0.conf ]; then
    echo "Создание конфигурации wg0.conf..."
    cat <<EOF > wg0.conf
[Interface]
Address = 10.0.0.1/24
SaveConfig = true
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o $NET_INTERFACE -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o $NET_INTERFACE -j MASQUERADE
ListenPort = 51820
PrivateKey = $SERVER_PRIV_KEY
EOF
fi

# Запуск WireGuard
echo "Запуск WireGuard..."
systemctl enable wg-quick@wg0
systemctl start wg-quick@wg0

# Настройка Python окружения
echo "Настройка Python окружения..."
# Определяем текущую директорию скрипта
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
cd "$SCRIPT_DIR"

# Создаем venv если нужно
python3 -m venv venv
source venv/bin/activate

echo "Установка библиотек Python..."
if [ -f requirements.txt ]; then
    pip install -r requirements.txt
else
    pip install python-telegram-bot qrcode[pil]
fi

echo "Установка завершена!"
echo "Ваш публичный ключ сервера: $SERVER_PUB_KEY"
echo "Теперь отредактируйте файл bot.py, вставив туда токен вашего Telegram бота."
echo "Запустите бота командой: ./venv/bin/python bot.py"
