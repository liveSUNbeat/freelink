import os
import subprocess
import logging
import re
import json
import time
import json
import time
import threading
from telegram import Update, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler, filters
import qrcode

# ==========================================
# НАСТРОЙКИ
# ==========================================
# Вставьте сюда токен, который выдал @BotFather
TOKEN = "8414028589:AAFWlbhjo6by7Z8dp_WohxEu0T10-LErHOQ"

# Путь к конфигурации WireGuard
WG_CONF_PATH = "/etc/wireguard/wg0.conf"
# Директория для хранения конфигов клиентов
CLIENTS_DIR = "clients"
# Публичный IP сервера (оставьте пустым для автоопределения)
SERVER_IP = "185.218.0.159"
# Порт WireGuard
WG_PORT = "51820"
USERS_FILE = "users.json"

# Логирование
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)

def get_server_ip():
    """Определяет внешний IP сервера."""
    global SERVER_IP
    if SERVER_IP:
        return SERVER_IP
    try:
        result = subprocess.run(['curl', '-s', 'ifconfig.me'], capture_output=True, text=True)
        return result.stdout.strip()
    except Exception as e:
        logging.error(f"Не удалось определить IP: {e}")
        return "127.0.0.1"

def get_server_public_key():
    """Читает публичный ключ сервера."""
    try:
        with open("/etc/wireguard/publickey", "r") as f:
            return f.read().strip()
    except Exception:
        return "ERROR_KEY_NOT_FOUND"

def get_next_ip():
    """Находит следующий свободный IP в подсети 10.0.0.x."""
    try:
        with open(WG_CONF_PATH, "r") as f:
            content = f.read()
        
        # Ищем все IP адреса клиентов
        ips = re.findall(r"AllowedIPs\s*=\s*10\.0\.0\.(\d+)/32", content)
        if not ips:
            return "10.0.0.2"
        
        ips = [int(ip) for ip in ips]
        next_octet = max(ips) + 1
        if next_octet > 254:
            raise Exception("Нет свободных IP адресов!")
        return f"10.0.0.{next_octet}"
    except FileNotFoundError:
        return "10.0.0.2"

def load_users():
    if not os.path.exists(USERS_FILE):
        return {}
    try:
        with open(USERS_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def save_users(data):
    with open(USERS_FILE, "w") as f:
        json.dump(data, f)

def enforce_expirations():
    users = load_users()
    now = int(time.time())
    changed = False
    for uid, info in list(users.items()):
        expires_at = int(info.get("expires_at", 0))
        disabled = bool(info.get("disabled", False))
        pub_key = info.get("pub_key")
        if expires_at and now >= expires_at and not disabled and pub_key:
            subprocess.run(["wg", "set", "wg0", "peer", pub_key, "remove"])
            subprocess.run(["wg-quick", "save", "wg0"])
            info["disabled"] = True
            changed = True
    if changed:
        save_users(users)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [KeyboardButton("➕ Создать VPN"), KeyboardButton("❓ Помощь")]
    ]
    await update.message.reply_text(
        "Привет! Я бот VPN.\nНажмите '➕ Создать VPN' для получения пробного доступа на 3 дня.",
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Я выдаю один пробный доступ на 3 дня на один Telegram‑аккаунт.\n"
        "Нажмите '➕ Создать VPN', и я пришлю конфиг и QR-код.\n"
        "Через 3 дня доступ автоматически отключится."
    )

def create_vpn_config(priv_key, server_pub_key, server_ip, client_ip):
    return f"""[Interface]
PrivateKey = {priv_key}
Address = {client_ip}/32
DNS = 8.8.8.8

[Peer]
PublicKey = {server_pub_key}
Endpoint = {server_ip}:{WG_PORT}
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
"""

async def handle_create_vpn(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = str(user.id)
    username = user.username or ""
    users = load_users()
    now = int(time.time())
    trial_seconds = 3 * 24 * 60 * 60

    enforce_expirations()

    info = users.get(user_id)
    if info:
        expires_at = int(info.get("expires_at", 0))
        if now < expires_at:
            await update.message.reply_text("У вас уже есть активный пробный доступ, второй бесплатно не выдаётся.")
            return
        await update.message.reply_text("Ваш пробный период уже использован, новый бесплатный доступ недоступен.")
        return

    client_name = username if username else f"user_{user_id}"
    await update.message.reply_text(f"Создаю пробный доступ для {client_name} на 3 дня...")

    try:
        priv_key = subprocess.run(["wg", "genkey"], capture_output=True, text=True).stdout.strip()
        proc = subprocess.Popen(["wg", "pubkey"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        pub_key_out, _ = proc.communicate(input=priv_key)
        pub_key = pub_key_out.strip()

        server_pub_key = get_server_public_key()
        server_ip = get_server_ip()
        client_ip = get_next_ip()

        client_config = create_vpn_config(priv_key, server_pub_key, server_ip, client_ip)

        os.makedirs(CLIENTS_DIR, exist_ok=True)
        config_filename = f"{CLIENTS_DIR}/{client_name}.conf"
        with open(config_filename, "w") as f:
            f.write(client_config)

        subprocess.run(["wg", "set", "wg0", "peer", pub_key, "allowed-ips", f"{client_ip}/32"])
        with open(WG_CONF_PATH, "a") as f:
            f.write(f"\n# {client_name}\n[Peer]\nPublicKey = {pub_key}\nAllowedIPs = {client_ip}/32\n")

        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(client_config)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        qr_filename = f"{CLIENTS_DIR}/{client_name}.png"
        img.save(qr_filename)

        expires_at = now + trial_seconds
        users[user_id] = {
            "username": username,
            "client_name": client_name,
            "created_at": now,
            "expires_at": expires_at,
            "pub_key": pub_key,
            "client_ip": client_ip,
            "disabled": False,
        }
        save_users(users)

        await update.message.reply_document(document=open(config_filename, "rb"), filename=f"{client_name}.conf")
        await update.message.reply_photo(
            photo=open(qr_filename, "rb"),
            caption="Доступ создан на 3 дня. После этого пир будет отключён."
        )

        keyboard = [[KeyboardButton("➕ Создать VPN"), KeyboardButton("❓ Помощь")]]
        await update.message.reply_text("Готово.", reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True))
    except Exception as e:
        logging.error(str(e))
        await update.message.reply_text("Ошибка.")
if __name__ == '__main__':
    # Проверка прав (нужен root для wg)
    if os.geteuid() != 0:
        print("Внимание! Бот должен быть запущен от root для управления WireGuard.")
    
    if TOKEN == "ВАШ_ТОКЕН_БОТА_ЗДЕСЬ":
        print("ОШИБКА: Вы не вставили токен бота в файл bot.py!")
        exit(1)

    application = ApplicationBuilder().token(TOKEN).build()
    enforce_expirations()
    def _enforcer_loop():
        while True:
            try:
                enforce_expirations()
            except Exception:
                pass
            time.sleep(600)
    threading.Thread(target=_enforcer_loop, daemon=True).start()
    
    application.add_handler(CommandHandler('start', start))
    application.add_handler(CommandHandler('help', help_command))
    application.add_handler(MessageHandler(filters.Regex('^➕ Создать VPN$'), handle_create_vpn))
    
    print("Бот запущен...")
    application.run_polling()
