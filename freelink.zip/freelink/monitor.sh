#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

INSTALL_DIR="${INSTALL_DIR:-/opt/freelink}"
XRAY_LOG="/var/log/xray/access.log"
BOT_LOG="$INSTALL_DIR/freelink.log"

echo -e "${BLUE}╔════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Freelink Bot - Monitor                ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════╝${NC}\n"

echo -e "${YELLOW}🔹 Статус Xray:${NC}"
if systemctl is-active --quiet xray; then
    echo -e "${GREEN}✅ Xray запущен${NC}"
    echo "   PID: $(systemctl show -p MainPID --value xray)"
else
    echo -e "${RED}❌ Xray остановлен${NC}"
fi
echo ""

echo -e "${YELLOW}🔹 Статус бота Freelink:${NC}"
if systemctl is-active --quiet freelink; then
    echo -e "${GREEN}✅ Бот запущен${NC}"
    echo "   PID: $(systemctl show -p MainPID --value freelink)"
else
    echo -e "${RED}❌ Бот остановлен${NC}"
fi
echo ""

echo -e "${YELLOW}🔹 Прослушиваемые порты:${NC}"
netstat -tlnp 2>/dev/null | grep -E "(443|10086)" || echo "   Порты не открыты"
echo ""

echo -e "${YELLOW}🔹 Проверка конфига Xray:${NC}"
if [ -f "/etc/xray/config.json" ]; then
    if python3 -m json.tool /etc/xray/config.json > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Конфиг корректен${NC}"
    else
        echo -e "${RED}❌ Ошибка синтаксиса JSON${NC}"
    fi
else
    echo -e "${RED}❌ Конфиг не найден${NC}"
fi
echo ""

echo -e "${YELLOW}🔹 Последние ошибки Xray:${NC}"
if [ -f "$XRAY_LOG" ]; then
    tail -5 "$XRAY_LOG" | grep -i error || echo "   ✅ Ошибок не найдено"
else
    echo "   ⚠️ Лог не найден"
fi
echo ""

echo -e "${YELLOW}🔹 Последние ошибки бота:${NC}"
if [ -f "$BOT_LOG" ]; then
    tail -5 "$BOT_LOG" | grep -i error || echo "   ✅ Ошибок не найдено"
else
    echo "   ⚠️ Лог не найден"
fi
echo ""

echo -e "${YELLOW}🔹 Использование диска:${NC}"
df -h / | tail -1 | awk '{print "   / : " $5 " (" $3 "/" $2 ")"}'
echo ""

echo -e "${YELLOW}🔹 SSL сертификаты:${NC}"
CERT_FILE="/etc/xray/certs/server.crt"
if [ -f "$CERT_FILE" ]; then
    EXPIRY=$(openssl x509 -in "$CERT_FILE" -noout -dates 2>/dev/null | grep notAfter | cut -d= -f2)
    DAYS_LEFT=$(echo "($(date -d \"$EXPIRY\" +%s) - $(date +%s)) / 86400" | bc)
    echo "   Истекает через: $DAYS_LEFT дней"
    if [ "$DAYS_LEFT" -lt 7 ]; then
        echo -e "   ${RED}⚠️ Сертификат истекает скоро!${NC}"
    fi
else
    echo -e "   ${RED}❌ Сертификат не найден${NC}"
fi
echo ""

echo -e "${YELLOW}🔹 Статистика:${NC}"
if [ -f "$INSTALL_DIR/users.json" ]; then
    USERS_COUNT=$(python3 -c "import json; data=json.load(open('$INSTALL_DIR/users.json')); print(len(data))" 2>/dev/null || echo "0")
    echo "   Пользователей: $USERS_COUNT"
fi
echo ""

echo -e "${YELLOW}📋 Полезные команды:${NC}"
echo "   Перезапуск Xray:  sudo systemctl restart xray"
echo "   Перезапуск бота:  sudo systemctl restart freelink"
echo "   Логи Xray:        sudo journalctl -u xray -f"
echo "   Логи бота:        sudo journalctl -u freelink -f"
echo ""

echo -e "${GREEN}✅ Мониторинг завершён${NC}\n"
