#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Freelink Telegram Bot for Xray Management
Управление подпиской через Xray сервер
"""

import os
import json
import asyncio
import logging
from datetime import datetime, timedelta
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Загружаем переменные окружения
load_dotenv()

# Логирование
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.getenv('BOT_LOG_PATH', 'freelink.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Конфигурация
BOT_TOKEN = os.getenv('BOT_TOKEN')
XRAY_CONFIG_PATH = os.getenv('XRAY_CONFIG_PATH', '/etc/xray/config.json')
XRAY_INBOUND_TAG = os.getenv('XRAY_INBOUND_TAG', 'vless_443')
SERVER_DOMAIN = os.getenv('SERVER_DOMAIN', 'example.com')
SERVER_IP = os.getenv('SERVER_IP', '1.2.3.4')
TRIAL_DAYS = int(os.getenv('TRIAL_DAYS', '3'))
USERS_FILE = os.getenv('USERS_FILE', 'users.json')

if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN не установлен в .env файле!")


def load_xray_config():
    """Загрузить конфигурацию Xray"""
    try:
        with open(XRAY_CONFIG_PATH, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Ошибка загрузки конфига: {e}")
        return None


def save_xray_config(config):
    """Сохранить конфигурацию Xray"""
    try:
        with open(XRAY_CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Ошибка сохранения конфига: {e}")
        return False


def load_users():
    """Загрузить список пользователей"""
    try:
        if os.path.exists(USERS_FILE):
            with open(USERS_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        logger.error(f"Ошибка загрузки пользователей: {e}")
    return {}


def save_users(users):
    """Сохранить список пользователей"""
    try:
        with open(USERS_FILE, 'w') as f:
            json.dump(users, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Ошибка сохранения пользователей: {e}")
        return False


def add_vless_user(user_id, uuid):
    """Добавить VLESS пользователя в конфиг Xray"""
    config = load_xray_config()
    if not config:
        return False
    
    try:
        #找到正确的inbound
        inbound = None
        for ib in config.get('inbounds', []):
            if ib.get('tag') == XRAY_INBOUND_TAG:
                inbound = ib
                break
        
        if not inbound:
            logger.error(f"Inbound {XRAY_INBOUND_TAG} не найден")
            return False
        
        # Добавить клиента
        if 'settings' not in inbound:
            inbound['settings'] = {'clients': []}
        if 'clients' not in inbound['settings']:
            inbound['settings']['clients'] = []
        
        # Проверить что клиента ещё нет
        for client in inbound['settings']['clients']:
            if client.get('id') == uuid:
                logger.warning(f"Клиент {uuid} уже существует")
                return True
        
        # Добавить нового клиента
        inbound['settings']['clients'].append({
            'id': uuid,
            'email': f'{user_id}@freelink'
        })
        
        return save_xray_config(config)
    except Exception as e:
        logger.error(f"Ошибка добавления пользователя: {e}")
        return False


def remove_vless_user(uuid):
    """Удалить VLESS пользователя из конфига Xray"""
    config = load_xray_config()
    if not config:
        return False
    
    try:
        for inbound in config.get('inbounds', []):
            if 'settings' in inbound and 'clients' in inbound['settings']:
                inbound['settings']['clients'] = [
                    c for c in inbound['settings']['clients'] 
                    if c.get('id') != uuid
                ]
        
        return save_xray_config(config)
    except Exception as e:
        logger.error(f"Ошибка удаления пользователя: {e}")
        return False


def generate_vless_url(uuid):
    """Генерировать VLESS URL"""
    url = f"vless://{uuid}@{SERVER_DOMAIN}:443?encryption=none&security=tls&sni={SERVER_DOMAIN}&type=tcp#Freelink"
    return url


def generate_qr_code(data):
    """Генерировать QR код"""
    try:
        import qrcode
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save('config_qr.png')
        return True
    except Exception as e:
        logger.error(f"Ошибка генерации QR: {e}")
        return False


def check_trial_expire():
    """Проверить и удалить истёкшие пробные учётные записи"""
    users = load_users()
    config = load_xray_config()
    now = datetime.now()
    
    expired = []
    for user_id, data in users.items():
        if 'trial_until' in data:
            try:
                trial_until = datetime.fromisoformat(data['trial_until'])
                if now > trial_until:
                    expired.append(user_id)
            except:
                pass
    
    for user_id in expired:
        uuid = users[user_id].get('uuid')
        if uuid:
            remove_vless_user(uuid)
        del users[user_id]
        logger.info(f"Удалён истёкший пробный учёт: {user_id}")
    
    if expired:
        save_users(users)
    
    return len(expired)


async def get_xray_status(context: ContextTypes.DEFAULT_TYPE = None) -> str:
    """Получить статус Xray"""
    try:
        import subprocess
        result = subprocess.run(
            ['systemctl', 'is-active', 'xray'],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if result.returncode == 0:
            return "✅ Xray запущен"
        else:
            return "❌ Xray остановлен"
    except Exception as e:
        logger.error(f"Ошибка проверки статуса: {e}")
        return "⚠️ Невозможно проверить статус"


# Telegram команды
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда /start"""
    user = update.effective_user
    msg = f"👋 Привет, {user.first_name}!\n\n"
    msg += "Это Freelink — Telegram бот для управления подпиской через Xray.\n\n"
    msg += "Для начала запроси пробный период (/trial) или свяжись с администратором.\n\n"
    msg += "Доступные команды:\n"
    msg += "/trial - Получить пробный доступ (3 дня)\n"
    msg += "/config - Получить конфиг подписки\n"
    msg += "/status - Статус сервера\n"
    msg += "/help - Справка\n"
    
    await update.message.reply_text(msg)
    logger.info(f"Пользователь {user.id} запустил бота")


async def trial(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда /trial - выдать пробный доступ"""
    import uuid as uuid_lib
    user = update.effective_user
    user_id = str(user.id)
    
    users = load_users()
    
    # Проверить что пользователь ещё не получал пробный доступ
    if user_id in users:
        msg = "❌ Вы уже получали пробный доступ!"
        await update.message.reply_text(msg)
        return
    
    # Генерировать UUID для пользователя
    user_uuid = str(uuid_lib.uuid4())
    trial_until = datetime.now() + timedelta(days=TRIAL_DAYS)
    
    # Сохранить в БД
    users[user_id] = {
        'uuid': user_uuid,
        'trial_until': trial_until.isoformat(),
        'created_at': datetime.now().isoformat()
    }
    save_users(users)
    
    # Добавить в Xray конфиг
    if not add_vless_user(user_id, user_uuid):
        msg = "❌ Ошибка при добавлении в систему. Свяжитесь с администратором."
        await update.message.reply_text(msg)
        return
    
    msg = f"✅ Пробный доступ выдан!\n\n"
    msg += f"Действителен до: {trial_until.strftime('%d.%m.%Y %H:%M')}\n"
    msg += f"Для получения конфигурации используй /config"
    
    await update.message.reply_text(msg)
    logger.info(f"Выданы пробные учётные данные пользователю {user_id}")


async def config(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда /config - отправить конфигурацию"""
    user = update.effective_user
    user_id = str(user.id)
    
    users = load_users()
    
    if user_id not in users:
        msg = "❌ Вы не зарегистрированы. Используйте /trial для пробного доступа."
        await update.message.reply_text(msg)
        return
    
    user_uuid = users[user_id]['uuid']
    vless_url = generate_vless_url(user_uuid)
    
    # Отправить URL
    msg = "📋 Ваша конфигурация подписки:\n\n"
    msg += f"`{vless_url}`\n\n"
    msg += "Скопируйте URL и импортируйте в Xray клиент (V2RayNG, Xray, и т.д.)\n"
    
    await update.message.reply_text(msg, parse_mode='Markdown')
    
    # Генерировать и отправить QR код
    if generate_qr_code(vless_url):
        with open('config_qr.png', 'rb') as f:
            await update.message.reply_photo(f)
    
    logger.info(f"Конфигурация отправлена пользователю {user_id}")


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда /status - статус сервера"""
    status_msg = await get_xray_status()
    msg = f"📊 Статус сервера:\n\n{status_msg}"
    await update.message.reply_text(msg)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда /help"""
    msg = "ℹ️ Справка по командам:\n\n"
    msg += "/start - Информация о боте\n"
    msg += "/trial - Получить пробный доступ (3 дня)\n"
    msg += "/config - Получить конфигурацию подписки\n"
    msg += "/status - Статус сервера Xray\n"
    msg += "/help - Эта справка\n\n"
    msg += "Для вопросов свяжитесь с администратором."
    
    await update.message.reply_text(msg)


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обработка обычных сообщений"""
    text = update.message.text
    
    if text.startswith('/'):
        return
    
    msg = "👋 Привет! Используйте команды (/ + команда) для управления подпиской.\n"
    msg += "Введите /help для справки."
    
    await update.message.reply_text(msg)


async def periodic_check(context: ContextTypes.DEFAULT_TYPE) -> None:
    """Периодическая проверка истёкших пробных учётов"""
    expired = check_trial_expire()
    if expired:
        logger.info(f"Удалено {expired} истёкших пробных учётов")


async def main():
    """Запуск бота"""
    logger.info("🚀 Запуск Freelink бота...")
    
    # Проверка конфига Xray
    if not load_xray_config():
        logger.error("❌ Невозможно загрузить конфиг Xray!")
        return
    
    # Создание приложения
    app = Application.builder().token(BOT_TOKEN).build()
    
    # Регистрация обработчиков команд
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("trial", trial))
    app.add_handler(CommandHandler("config", config))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("help", help_cmd))
    
    # Обработчик обычных сообщений
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    # Периодическая проверка (каждый час)
    app.job_queue.run_repeating(periodic_check, interval=3600, first=60)
    
    logger.info("✅ Бот готов к работе")
    
    # Запуск
    await app.run_polling()


if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("⏹️ Бот остановлен")
    except Exception as e:
        logger.error(f"❌ Критическая ошибка: {e}")
