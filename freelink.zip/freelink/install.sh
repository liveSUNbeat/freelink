#!/bin/bash

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}=== Freelink Bot - Установка ===${NC}\n"

if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}❌ Скрипт должен быть запущен от root!${NC}"
   exit 1
fi

INSTALL_DIR="/opt/freelink"
BOT_USER="freelink"
BOT_HOME="/home/$BOT_USER"
XRAY_CONFIG="/etc/xray/config.json"
CERTS_DIR="/etc/xray/certs"
LOG_DIR="/var/log/xray"
BOT_LOG_DIR="/var/log/freelink"

echo -e "${YELLOW}1️⃣ Установка зависимостей...${NC}"
apt-get update
apt-get upgrade -y
apt-get install -y python3 python3-pip python3-venv curl wget git certbot systemd

pip3 install --upgrade pip setuptools wheel
pip3 install python-telegram-bot==21.11 python-dotenv==1.0.1 qrcode[pil]==8.0 requests==2.31.0

echo -e "${GREEN}✅ Зависимости установлены${NC}\n"

echo -e "${YELLOW}2️⃣ Установка Xray...${NC}"
XRAY_VERSION=$(curl -s "https://api.github.com/repos/XTLS/Xray-core/releases/latest" | grep "tag_name" | cut -d'"' -f4 | tr -d 'v')

if command -v xray &> /dev/null; then
    echo -e "${GREEN}✅ Xray уже установлен${NC}"
else
    cd /tmp
    wget -q "https://github.com/XTLS/Xray-core/releases/download/v${XRAY_VERSION}/Xray-linux-64.zip"
    unzip -q Xray-linux-64.zip
    mkdir -p /usr/local/bin
    mv xray /usr/local/bin/
    chmod +x /usr/local/bin/xray
    rm -f Xray-linux-64.zip
    cd -
    echo -e "${GREEN}✅ Xray v${XRAY_VERSION} установлен${NC}"
fi

mkdir -p "$CERTS_DIR" "$LOG_DIR"
chmod 700 "$CERTS_DIR"
chmod 755 "$LOG_DIR"

echo -e "${YELLOW}   ⚠️ Важно! Добавьте SSL сертификаты в $CERTS_DIR:${NC}"
echo -e "${YELLOW}   - server.crt${NC}"
echo -e "${YELLOW}   - server.key${NC}\n"

echo -e "${YELLOW}3️⃣ Создание пользователя бота...${NC}"
if id "$BOT_USER" &>/dev/null; then
    echo -e "${GREEN}✅ Пользователь $BOT_USER существует${NC}"
else
    useradd -r -s /bin/bash -d "$BOT_HOME" -m "$BOT_USER"
    echo -e "${GREEN}✅ Создан пользователь $BOT_USER${NC}"
fi

echo -e "${YELLOW}4️⃣ Копирование файлов бота...${NC}"
mkdir -p "$INSTALL_DIR"
cp bot_freelink.py "$INSTALL_DIR/"
cp config.json "$INSTALL_DIR/"
cp .env.example "$INSTALL_DIR/"

mkdir -p "$BOT_LOG_DIR"
chown "$BOT_USER:$BOT_USER" "$BOT_LOG_DIR"
chmod 755 "$BOT_LOG_DIR"

if [ ! -f "$XRAY_CONFIG" ]; then
    mkdir -p /etc/xray
    cp config.json "$XRAY_CONFIG"
    echo -e "${YELLOW}   ⚠️ Не забудьте отредактировать $XRAY_CONFIG!${NC}"
fi

chmod 644 "$XRAY_CONFIG"
chown root:root "$XRAY_CONFIG"

echo -e "${GREEN}✅ Файлы скопированы в $INSTALL_DIR${NC}\n"

echo -e "${YELLOW}5️⃣ Подготовка конфигурации...${NC}"
if [ ! -f "$INSTALL_DIR/.env" ]; then
    cp "$INSTALL_DIR/.env.example" "$INSTALL_DIR/.env"
    echo -e "${YELLOW}   ⚠️ Отредактируйте $INSTALL_DIR/.env${NC}"
fi

chmod 600 "$INSTALL_DIR/.env"
chown "$BOT_USER:$BOT_USER" "$INSTALL_DIR/.env"

echo -e "${YELLOW}6️⃣ Создание systemd service...${NC}"
cat > /etc/systemd/system/freelink.service <<EOF
[Unit]
Description=Freelink Telegram Bot for Xray
After=network-online.target xray.service
Wants=network-online.target

[Service]
Type=simple
User=$BOT_USER
WorkingDirectory=$INSTALL_DIR
Environment="PATH=/usr/local/bin:/usr/bin:/bin"
ExecStart=/usr/bin/python3 $INSTALL_DIR/bot_freelink.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=freelink

[Install]
WantedBy=multi-user.target
EOF

if [ ! -f /etc/systemd/system/xray.service ]; then
    echo -e "${YELLOW}7️⃣ Создание systemd service для Xray...${NC}"
    cat > /etc/systemd/system/xray.service <<'EOF'
[Unit]
Description=Xray Service
After=syslog.target network-online.target remote-fs.target nss-lookup.target
Wants=network-online.target

[Service]
Type=simple
User=root
CapabilityBoundingSet=CAP_NET_BIND_SERVICE CAP_NET_RAW
AmbientCapabilities=CAP_NET_BIND_SERVICE CAP_NET_RAW
NoNewPrivileges=true
ExecStart=/usr/local/bin/xray run -c /etc/xray/config.json
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    chmod 644 /etc/systemd/system/xray.service
fi

echo -e "${YELLOW}8️⃣ Активация service...${NC}"
systemctl daemon-reload
systemctl enable xray.service
systemctl enable freelink.service

echo -e "${GREEN}✅ Service включены${NC}\n"

echo -e "${YELLOW}9️⃣ Настройка logrotate...${NC}"
cat > /etc/logrotate.d/freelink <<EOF
$BOT_LOG_DIR/freelink.log {
    daily
    rotate 7
    compress
    delaycompress
    notifempty
    create 0640 $BOT_USER $BOT_USER
    sharedscripts
}
EOF

cat > /etc/logrotate.d/xray <<EOF
/var/log/xray/*.log {
    daily
    rotate 10
    compress
    delaycompress
    notifempty
    create 0640 root root
    sharedscripts
}
EOF

echo -e "${GREEN}✅ Logrotate настроен${NC}\n"

echo -e "${GREEN}═══════════════════════════════════════${NC}"
echo -e "${GREEN}✅ Установка завершена!${NC}"
echo -e "${GREEN}═══════════════════════════════════════${NC}\n"

echo -e "${YELLOW}📝 Следующие шаги:${NC}\n"
echo "1️⃣ Подготовьте SSL сертификаты:"
echo -e "   ${RED}sudo mkdir -p /etc/xray/certs${NC}"
echo -e "   ${RED}sudo cp server.crt /etc/xray/certs/${NC}"
echo -e "   ${RED}sudo cp server.key /etc/xray/certs/${NC}\n"

echo "2️⃣ Отредактируйте конфиги:"
echo -e "   ${RED}sudo nano /opt/freelink/.env${NC}"
echo -e "   ${RED}sudo nano /etc/xray/config.json${NC}\n"

echo "3️⃣ Запустите сервисы:"
echo -e "   ${RED}sudo systemctl start xray${NC}"
echo -e "   ${RED}sudo systemctl start freelink${NC}\n"

echo "4️⃣ Проверьте статус:"
echo -e "   ${RED}sudo systemctl status xray${NC}"
echo -e "   ${RED}sudo systemctl status freelink${NC}\n"

echo "5️⃣ Просмотрите логи:"
echo -e "   ${RED}sudo journalctl -u freelink -f${NC}\n"

echo -e "${GREEN}🚀 Готово!${NC}\n"
