# 🎯 Freelink - Быстрый старт

Всё что нужно для запуска на Linux сервере.

## ⚡ Самое важное (5 минут)

### 1. Загрузить файлы на сервер
```bash
# С Windows PowerShell:
scp -r "C:\freelink" root@ваш-ip:/freelink/
```

### 2. На сервере - конфигурация
```bash
cd /freelink
cp .env.example .env
nano .env  # Заполните: BOT_TOKEN, SERVER_DOMAIN
```

### 3. SSL сертификаты (ОБЯЗАТЕЛЬНО!)
```bash
sudo mkdir -p /etc/xray/certs
sudo cp /path/to/server.crt /etc/xray/certs/
sudo cp /path/to/server.key /etc/xray/certs/
sudo chmod 600 /etc/xray/certs/*
```

### 4. Установка
```bash
sudo bash install.sh
```

### 5. Запуск
```bash
sudo systemctl restart xray
sudo systemctl restart freelink
./monitor.sh
```

## 📋 Что в папке

- **bot_freelink.py** - Telegram бот
- **config.json** - Конфиг Xray
- **.env.example** - Пример переменных
- **install.sh** - Установка (требует sudo)
- **monitor.sh** - Мониторинг
- **check.sh** - Проверка перед установкой

## ⚠️ Обязательные данные для .env

```
BOT_TOKEN=123456:ABC...          # От @BotFather
XRAY_CONFIG_PATH=/etc/xray/config.json
SERVER_DOMAIN=your-domain.com    # Ваш домен
SERVER_IP=1.2.3.4               # IP сервера
```

## 🔧 Основные команды

```bash
# Проверка готовности
./check.sh

# Запуск сервисов
sudo systemctl start xray
sudo systemctl start freelink

# Статус
./monitor.sh

# Логи
sudo journalctl -u freelink -f
```

## ❌ Если не работает

```bash
./check.sh           # Диагностика
sudo journalctl -u xray -n 50      # Логи Xray
sudo journalctl -u freelink -n 50  # Логи бота
xray test -c /etc/xray/config.json # Проверка конфига
```

---

**Версия**: 1.0  
**Готово к использованию**: ✅
