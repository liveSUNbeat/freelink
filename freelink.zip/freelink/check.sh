#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

FAILED=0
PASSED=0

echo -e "${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Freelink Bot - Pre-deployment Check                  ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}\n"

echo -e "${YELLOW}🔹 Проверка Python зависимостей...${NC}"
PYTHON_MODULES=("telegram" "dotenv" "qrcode" "requests")

for module in "${PYTHON_MODULES[@]}"; do
    if python3 -c "import $module" 2>/dev/null; then
        echo -e "${GREEN}  ✅ $module${NC}"
        ((PASSED++))
    else
        echo -e "${RED}  ❌ $module (не установлен)${NC}"
        ((FAILED++))
    fi
done
echo ""

echo -e "${YELLOW}🔹 Проверка файлов...${NC}"
FILES=("bot_freelink.py" "config.json" ".env.example")

for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}  ✅ $file${NC}"
        ((PASSED++))
    else
        echo -e "${RED}  ❌ $file (не найден)${NC}"
        ((FAILED++))
    fi
done
echo ""

echo -e "${YELLOW}🔹 Проверка синтаксиса Python...${NC}"
if python3 -m py_compile bot_freelink.py 2>/dev/null; then
    echo -e "${GREEN}  ✅ bot_freelink.py${NC}"
    ((PASSED++))
else
    echo -e "${RED}  ❌ bot_freelink.py (синтаксическая ошибка)${NC}"
    ((FAILED++))
fi
echo ""

echo -e "${YELLOW}🔹 Проверка JSON конфига...${NC}"
if python3 -m json.tool config.json > /dev/null 2>&1; then
    echo -e "${GREEN}  ✅ config.json${NC}"
    ((PASSED++))
else
    echo -e "${RED}  ❌ config.json (JSON ошибка)${NC}"
    ((FAILED++))
fi
echo ""

echo -e "${YELLOW}🔹 Проверка .env файла...${NC}"
if [ -f ".env" ]; then
    echo -e "${GREEN}  ✅ .env существует${NC}"
    ((PASSED++))
    
    BOT_TOKEN=$(grep "BOT_TOKEN=" .env | cut -d= -f2)
    if [ -z "$BOT_TOKEN" ] || [ "$BOT_TOKEN" = "YOUR_BOT_TOKEN_HERE" ]; then
        echo -e "${YELLOW}  ⚠️  BOT_TOKEN не установлен${NC}"
        ((FAILED++))
    else
        echo -e "${GREEN}  ✅ BOT_TOKEN установлен${NC}"
        ((PASSED++))
    fi
else
    echo -e "${RED}  ❌ .env не найден${NC}"
    ((FAILED++))
fi
echo ""

TOTAL=$((PASSED + FAILED))

echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}РЕЗУЛЬТАТЫ ПРОВЕРКИ${NC}"
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}\n"

echo -e "✅ Прошли: ${GREEN}$PASSED${NC}"
echo -e "❌ Ошибки: ${RED}$FAILED${NC}\n"

if [ $TOTAL -gt 0 ]; then
    PERCENT=$((PASSED * 100 / TOTAL))
    if [ $PERCENT -ge 90 ]; then
        STATUS="${GREEN}✅ ГОТОВО К РАЗВЁРТЫВАНИЮ${NC}"
    elif [ $PERCENT -ge 70 ]; then
        STATUS="${YELLOW}⚠️  ЕСТЬ ОШИБКИ${NC}"
    else
        STATUS="${RED}❌ КРИТИЧЕСКИЕ ОШИБКИ${NC}"
    fi
    echo -e "Статус: $STATUS (${PERCENT}%)\n"
fi

if [ $FAILED -gt 0 ]; then
    echo -e "${YELLOW}📋 Что нужно исправить:${NC}\n"
    
    if ! python3 -c "import telegram" 2>/dev/null; then
        echo "   pip3 install python-telegram-bot==21.11"
    fi
    
    if [ ! -f ".env" ]; then
        echo "   cp .env.example .env"
        echo "   nano .env"
    fi
fi

echo ""
echo -e "${GREEN}✅ Проверка завершена${NC}\n"
